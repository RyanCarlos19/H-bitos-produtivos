package com.productivehabits.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

class TrackingService : Service(), LocationListener {

    private var wakeLock: PowerManager.WakeLock? = null
    private var listening = false
    private var gpsOff = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Tracker.ensureLoaded(this)
        when (intent?.action) {
            ACTION_START -> {
                Tracker.start(this, intent.getStringExtra("type") ?: "run")
                begin()
            }
            ACTION_TOGGLE -> {
                if (!Tracker.active) { stopSelf(); return START_NOT_STICKY }
                if (Tracker.paused) Tracker.resume(this) else Tracker.pause(this)
                applyState()
            }
            ACTION_STOP -> {
                finishTracking()
                return START_NOT_STICKY
            }
            else -> {
                if (Tracker.active) begin() else { stopSelf(); return START_NOT_STICKY }
            }
        }
        return START_STICKY
    }

    private fun begin() {
        createChannel()
        try {
            val n = buildNotification()
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (e: Exception) {
            stopSelf()
            return
        }
        acquireWakeLock()
        applyState()
    }

    private fun applyState() {
        if (Tracker.paused) stopLocation() else startLocation()
        updateNotification()
    }

    @SuppressLint("MissingPermission")
    private fun startLocation() {
        if (listening) return
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        try {
            gpsOff = !lm.isProviderEnabled(LocationManager.GPS_PROVIDER)
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000L, 0f, this, Looper.getMainLooper())
            listening = true
        } catch (e: SecurityException) {
            finishTracking()
        }
    }

    private fun stopLocation() {
        if (!listening) return
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        try { lm.removeUpdates(this) } catch (e: Exception) {}
        listening = false
    }

    private fun finishTracking() {
        Tracker.finish(this)
        stopLocation()
        releaseWakeLock()
        stopForeground(true)
        stopSelf()
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ProductiveHabits:tracking").apply {
            acquire(6 * 60 * 60 * 1000L)
        }
    }

    private fun releaseWakeLock() {
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (e: Exception) {}
        wakeLock = null
    }

    override fun onDestroy() {
        stopLocation()
        releaseWakeLock()
        super.onDestroy()
    }

    // ---- LocationListener ----
    override fun onLocationChanged(location: Location) {
        Tracker.onLocation(this, location)
        updateNotification()
    }

    override fun onProviderEnabled(provider: String) {
        if (provider == LocationManager.GPS_PROVIDER) { gpsOff = false; updateNotification() }
    }

    override fun onProviderDisabled(provider: String) {
        if (provider == LocationManager.GPS_PROVIDER) { gpsOff = true; updateNotification() }
    }

    @Deprecated("Deprecated in Java")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}

    // ---- Notificação (aparece também na tela de bloqueio) ----
    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL, "Atividade física", NotificationManager.IMPORTANCE_LOW)
        ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        ch.setShowBadge(false)
        nm.createNotificationChannel(ch)
    }

    private fun updateNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        val toggle = PendingIntent.getService(
            this, 11, Intent(this, TrackingService::class.java).setAction(ACTION_TOGGLE), flags
        )
        val stop = PendingIntent.getService(
            this, 12, Intent(this, TrackingService::class.java).setAction(ACTION_STOP), flags
        )
        val icon = Icon.createWithResource(this, R.drawable.ic_stat)

        val title = "${Tracker.emoji()} ${Tracker.verb()} • ${Fmt.distance(Tracker.distance)}"
        val text = when {
            Tracker.paused -> "Pausado"
            gpsOff -> "GPS desligado: ligue a localização"
            else -> Tracker.paceText()
        }

        val b = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(Notification.Action.Builder(icon, if (Tracker.paused) "Retomar" else "Pausar", toggle).build())
            .addAction(Notification.Action.Builder(icon, "Finalizar", stop).build())

        if (!Tracker.paused) {
            b.setShowWhen(true)
                .setUsesChronometer(true)
                .setWhen(System.currentTimeMillis() - Tracker.elapsed())
        } else {
            b.setShowWhen(false).setUsesChronometer(false)
        }
        if (Build.VERSION.SDK_INT >= 31) {
            b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        }
        return b.build()
    }

    companion object {
        const val ACTION_START = "com.productivehabits.app.TRACK_START"
        const val ACTION_TOGGLE = "com.productivehabits.app.TRACK_TOGGLE"
        const val ACTION_STOP = "com.productivehabits.app.TRACK_STOP"
        private const val CHANNEL = "tracking"
        private const val NOTIF_ID = 4242
    }
}
