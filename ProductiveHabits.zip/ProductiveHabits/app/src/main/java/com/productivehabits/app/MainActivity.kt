package com.productivehabits.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Bundle
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.speech.RecognizerIntent
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var pendingType: String? = null
    private var cameraFile: File? = null
    private var warmListener: LocationListener? = null
    private val warmHandler = Handler(Looper.getMainLooper())
    private val warmStop = Runnable { stopWarmup() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.userAgentString = web.settings.userAgentString + " ProductiveHabits/1.0"
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")

        askNotificationPermission()
        try { Scheduler.scheduleAll(this) } catch (e: Exception) {}
    }

    override fun onPause() {
        stopWarmup()
        super.onPause()
    }

    @SuppressLint("MissingPermission")
    private fun startWarmup() {
        if (!hasFineLocation() || Tracker.active) return
        warmHandler.removeCallbacks(warmStop)
        warmHandler.postDelayed(warmStop, 20000)
        if (warmListener != null) return
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        val l = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                Tracker.lastLat = location.latitude
                Tracker.lastLon = location.longitude
                Tracker.lastAcc = if (location.hasAccuracy()) location.accuracy else 99f
                Tracker.lastFixAt = System.currentTimeMillis()
            }

            @Deprecated("Deprecated in Java")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, l, Looper.getMainLooper())
            warmListener = l
        } catch (e: Exception) {
        }
    }

    private fun stopWarmup() {
        warmHandler.removeCallbacks(warmStop)
        val l = warmListener ?: return
        try {
            (getSystemService(LOCATION_SERVICE) as LocationManager).removeUpdates(l)
        } catch (e: Exception) {
        }
        warmListener = null
    }

    override fun onResume() {
        super.onResume()
        try { HabitWidget.updateAll(this) } catch (e: Exception) {}
        reloadState()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_LOCATION) {
            val type = pendingType
            pendingType = null
            if (hasFineLocation() && type != null) {
                launchTracking(type)
            } else if (!hasFineLocation()) {
                web.evaluateJavascript("window.__locDenied && window.__locDenied()", null)
            }
        }
        reloadState()
    }

    @Suppress("DEPRECATION")
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_VOICE -> if (resultCode == RESULT_OK) {
                val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
                if (text != null) {
                    web.evaluateJavascript("window.__voiceResult && window.__voiceResult(" + JSONObject.quote(text) + ")", null)
                }
            }
            REQ_RINGTONE -> if (resultCode == RESULT_OK) {
                val uri = data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
                if (uri != null) {
                    val title = try {
                        RingtoneManager.getRingtone(this, uri)?.getTitle(this) ?: "Som do sistema"
                    } catch (e: Exception) { "Som do sistema" }
                    AlarmSound.set(this, "system", uri.toString(), title)
                    reloadState()
                }
            }
            REQ_AUDIO -> if (resultCode == RESULT_OK) {
                data?.data?.let { copySound(it) }
            }
            REQ_CAMERA -> if (resultCode == RESULT_OK) {
                val id = Photos.pending(this)
                val f = cameraFile
                if (id != null && f != null && f.exists()) {
                    Thread {
                        Photos.saveFromFile(this, id, f)
                        try { f.delete() } catch (e: Exception) {}
                        runOnUiThread { photoSaved() }
                    }.start()
                }
            }
            REQ_FCAM -> if (resultCode == RESULT_OK) {
                val f = cameraFile
                if (f != null && f.exists()) {
                    Thread {
                        val uri = Photos.saveFoodTmpFromFile(this, f)
                        try { f.delete() } catch (e: Exception) {}
                        runOnUiThread { foodPhotoReady(uri) }
                    }.start()
                }
            }
            REQ_FGAL -> if (resultCode == RESULT_OK) {
                val uri = data?.data
                if (uri != null) {
                    Thread {
                        val d = Photos.saveFoodTmpFromUri(this, uri)
                        runOnUiThread { foodPhotoReady(d) }
                    }.start()
                }
            }
            REQ_GALLERY -> if (resultCode == RESULT_OK) {
                val id = Photos.pending(this)
                val uri = data?.data
                if (id != null && uri != null) {
                    Thread {
                        Photos.saveFromUri(this, id, uri)
                        runOnUiThread { photoSaved() }
                    }.start()
                }
            }
        }
    }

    private fun foodPhotoReady(dataUri: String) {
        web.evaluateJavascript("window.__foodPhoto && window.__foodPhoto(" + JSONObject.quote(dataUri) + ")", null)
    }

    private fun photoSaved() {
        web.evaluateJavascript("window.__photoSaved && window.__photoSaved()", null)
    }

    private fun copySound(uri: Uri) {
        Thread {
            var out: File? = null
            try {
                var name = "som"
                contentResolver.query(uri, null, null, null, null)?.use { c ->
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (c.moveToFirst() && i >= 0) name = c.getString(i) ?: "som"
                }
                val ext = name.substringAfterLast('.', "mp3").lowercase().filter { it.isLetterOrDigit() }.take(5).ifEmpty { "mp3" }
                val dir = File(filesDir, "sounds").apply { mkdirs() }
                dir.listFiles()?.forEach { it.delete() }
                out = File(dir, "alarme_${System.currentTimeMillis()}.$ext")
                var total = 0L
                contentResolver.openInputStream(uri)?.use { ins ->
                    out.outputStream().use { os ->
                        val buf = ByteArray(65536)
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            total += n
                            if (total > 30L * 1024 * 1024) throw Exception("arquivo muito grande")
                            os.write(buf, 0, n)
                        }
                    }
                }
                AlarmSound.set(this, "file", out.name, name)
            } catch (e: Exception) {
                try { out?.delete() } catch (x: Exception) {}
                runOnUiThread { web.evaluateJavascript("window.__soundFail && window.__soundFail()", null) }
            }
            runOnUiThread { reloadState() }
        }.start()
    }

    private fun startVoice() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Diga seu compromisso")
        try {
            startActivityForResult(i, REQ_VOICE)
        } catch (e: Exception) {
            web.evaluateJavascript("window.__voiceFail && window.__voiceFail()", null)
        }
    }

    private fun launchCamera(code: Int = REQ_CAMERA) {
        try {
            val dir = File(cacheDir, "images").apply { mkdirs() }
            val f = File(dir, "cam_${System.currentTimeMillis()}.jpg")
            cameraFile = f
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                .putExtra(MediaStore.EXTRA_OUTPUT, uri)
                .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivityForResult(i, code)
        } catch (e: Exception) {
            web.evaluateJavascript("window.__photoFail && window.__photoFail()", null)
        }
    }

    private fun launchGallery(code: Int = REQ_GALLERY) {
        try {
            val i = Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE)
            startActivityForResult(Intent.createChooser(i, "Escolher foto"), code)
        } catch (e: Exception) {
            web.evaluateJavascript("window.__photoFail && window.__photoFail()", null)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    private fun reloadState() {
        if (::web.isInitialized) {
            web.evaluateJavascript("window.__reload && window.__reload()", null)
        }
    }

    private fun hasNotifPermission(): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun hasFineLocation(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun hasAnyLocation(): Boolean =
        hasFineLocation() || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun askNotificationPermission() {
        if (!hasNotifPermission()) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
        }
    }

    private fun launchTracking(type: String) {
        if (Tracker.active) return
        val i = Intent(this, TrackingService::class.java)
            .setAction(TrackingService.ACTION_START)
            .putExtra("type", type)
        startForegroundService(i)
    }

    inner class Bridge {
        @JavascriptInterface
        fun getState(): String? = Store.get(this@MainActivity)

        @JavascriptInterface
        fun saveState(json: String) {
            Store.put(this@MainActivity, json)
            try { HabitWidget.updateAll(this@MainActivity) } catch (e: Exception) {}
            try { Scheduler.scheduleAll(this@MainActivity) } catch (e: Exception) {}
        }

        @JavascriptInterface
        fun notifGranted(): Boolean = hasNotifPermission()

        @JavascriptInterface
        fun requestNotifications() {
            runOnUiThread { askNotificationPermission() }
        }

        @JavascriptInterface
        fun testNotification(id: String) {
            Store.habits(this@MainActivity).find { it.id == id }?.let {
                Notifier.show(this@MainActivity, it)
            }
        }

        // ---- Voz, frase do dia ----
        @JavascriptInterface
        fun startVoice() {
            runOnUiThread { this@MainActivity.startVoice() }
        }

        @JavascriptInterface
        fun getQuote(): String = Quotes.forToday(this@MainActivity).toJson()

        @JavascriptInterface
        fun testQuote() {
            QuoteNotifier.show(this@MainActivity, Quotes.forToday(this@MainActivity))
        }

        // ---- Som do alarme ----
        @JavascriptInterface
        fun getSound(): String = AlarmSound.json(this@MainActivity)

        @JavascriptInterface
        fun setSoundDefault() {
            AlarmSound.set(this@MainActivity, "default", "", "Padrão do celular")
        }

        @JavascriptInterface
        fun setSoundRaw(name: String, label: String) {
            AlarmSound.set(this@MainActivity, "raw", name, label)
        }

        @JavascriptInterface
        fun pickSystemSound() {
            runOnUiThread {
                val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                    .putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALL)
                    .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, false)
                    .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                    .putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Som do alarme")
                try { startActivityForResult(i, REQ_RINGTONE) } catch (e: Exception) {}
            }
        }

        @JavascriptInterface
        fun pickSoundFile() {
            runOnUiThread {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                    .setType("audio/*")
                    .addCategory(Intent.CATEGORY_OPENABLE)
                try { startActivityForResult(i, REQ_AUDIO) } catch (e: Exception) {}
            }
        }

        @JavascriptInterface
        fun previewSound(kind: String, value: String) {
            AlarmSound.preview(this@MainActivity, kind, value)
        }

        @JavascriptInterface
        fun stopPreview() {
            AlarmSound.stopPreview()
        }

        @JavascriptInterface
        fun testAlarm() {
            val h = Habit(
                id = "teste", name = "Teste de alarme", emoji = "⏰", color = Color.BLUE, time = "",
                days = emptyList(), doneToday = false, streak = 0, created = "", done = emptySet(), alarm = true
            )
            Notifier.show(this@MainActivity, h)
        }

        // ---- Atividades físicas ----
        @JavascriptInterface
        fun getTracking(): String = Tracker.snapshot(this@MainActivity)

        @JavascriptInterface
        fun getSessions(): String = Tracker.sessionsJson(this@MainActivity)

        @JavascriptInterface
        fun getLiveRoute(from: Int): String = Tracker.liveRoute(from)

        @JavascriptInterface
        fun getRoute(id: String): String = Tracker.routeFor(this@MainActivity, id)

        @JavascriptInterface
        fun deleteSession(id: String) {
            Tracker.deleteSession(this@MainActivity, id)
        }

        @JavascriptInterface
        fun hasLocation(): Boolean = hasAnyLocation()

        @JavascriptInterface
        fun requestLocation() {
            runOnUiThread {
                if (!hasFineLocation()) {
                    pendingType = null
                    requestPermissions(
                        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                        REQ_LOCATION
                    )
                }
            }
        }

        @SuppressLint("MissingPermission")
        @JavascriptInterface
        fun getLastLocation(): String {
            if (!Tracker.lastLat.isNaN() && !Tracker.lastLon.isNaN()) {
                val age = if (Tracker.lastFixAt > 0) System.currentTimeMillis() - Tracker.lastFixAt else 999999L
                return "${Tracker.lastLat},${Tracker.lastLon},${Tracker.lastAcc},$age"
            }
            if (!hasAnyLocation()) return ""
            return try {
                val lm = getSystemService(LOCATION_SERVICE) as LocationManager
                var best: Location? = null
                for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)) {
                    val l = try { lm.getLastKnownLocation(p) } catch (e: Exception) { null }
                    if (l != null && (best == null || l.time > best.time)) best = l
                }
                if (best != null) "${best.latitude},${best.longitude},${if (best.hasAccuracy()) best.accuracy else 99f},${System.currentTimeMillis() - best.time}" else ""
            } catch (e: Exception) {
                ""
            }
        }

        @SuppressLint("MissingPermission")
        @JavascriptInterface
        fun locateOnce() {
            runOnUiThread {
                if (!hasAnyLocation()) return@runOnUiThread
                val lm = getSystemService(LOCATION_SERVICE) as LocationManager
                val listener = object : LocationListener {
                    override fun onLocationChanged(location: Location) {
                        Tracker.lastLat = location.latitude
                        Tracker.lastLon = location.longitude
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                    override fun onProviderEnabled(provider: String) {}
                    override fun onProviderDisabled(provider: String) {}
                }
                for (p in listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER)) {
                    try {
                        if (lm.isProviderEnabled(p)) {
                            @Suppress("DEPRECATION")
                            lm.requestSingleUpdate(p, listener, Looper.getMainLooper())
                        }
                    } catch (e: Exception) {
                    }
                }
            }
        }

        @JavascriptInterface
        fun gpsWarmup() {
            runOnUiThread { startWarmup() }
        }

        // ---- Calorias ----
        @JavascriptInterface
        fun hasApiKey(): Boolean = FoodAnalyzer.hasKey(this@MainActivity)

        @JavascriptInterface
        fun setApiKey(key: String) {
            FoodAnalyzer.setKey(this@MainActivity, key)
        }

        @JavascriptInterface
        fun pickFoodPhoto(source: String) {
            runOnUiThread {
                if (source == "camera") launchCamera(REQ_FCAM) else launchGallery(REQ_FGAL)
            }
        }

        @JavascriptInterface
        fun clearFoodPhoto() {
            Photos.clearFoodTmp(this@MainActivity)
        }

        @JavascriptInterface
        fun analyzeMeal(description: String, existingId: String) {
            val tmp = Photos.foodTmp(this@MainActivity)
            val img: File? = when {
                tmp.exists() -> tmp
                existingId.isNotEmpty() && Photos.mealFile(this@MainActivity, existingId).exists() -> Photos.mealFile(this@MainActivity, existingId)
                else -> null
            }
            if (img == null && description.trim().isEmpty()) {
                runOnUiThread {
                    web.evaluateJavascript("window.__foodError && window.__foodError(" + JSONObject.quote("Envie uma foto ou descreva a refeição.") + ")", null)
                }
                return
            }
            FoodAnalyzer.analyze(
                this@MainActivity, description, img,
                onResult = { json ->
                    runOnUiThread { web.evaluateJavascript("window.__foodResult && window.__foodResult(" + JSONObject.quote(json) + ")", null) }
                },
                onError = { msg ->
                    runOnUiThread { web.evaluateJavascript("window.__foodError && window.__foodError(" + JSONObject.quote(msg) + ")", null) }
                }
            )
        }

        @JavascriptInterface
        fun commitMealPhoto(id: String): Boolean = Photos.commitMeal(this@MainActivity, id)

        @JavascriptInterface
        fun getMealThumb(id: String): String = Photos.mealThumbUri(this@MainActivity, id)

        @JavascriptInterface
        fun getMealPhoto(id: String): String = Photos.mealPhotoUri(this@MainActivity, id)

        @JavascriptInterface
        fun deleteMealPhoto(id: String) {
            Photos.deleteMeal(this@MainActivity, id)
        }

        @JavascriptInterface
        fun startTracking(type: String) {
            runOnUiThread {
                if (!hasFineLocation()) {
                    pendingType = type
                    requestPermissions(
                        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                        REQ_LOCATION
                    )
                } else {
                    launchTracking(type)
                }
            }
        }

        @JavascriptInterface
        fun togglePause() {
            startService(Intent(this@MainActivity, TrackingService::class.java).setAction(TrackingService.ACTION_TOGGLE))
        }

        @JavascriptInterface
        fun stopTracking() {
            startService(Intent(this@MainActivity, TrackingService::class.java).setAction(TrackingService.ACTION_STOP))
        }

        // ---- Fotos das atividades ----
        @JavascriptInterface
        fun addPhoto(id: String, source: String) {
            runOnUiThread {
                Photos.setPending(this@MainActivity, id)
                if (source == "camera") launchCamera() else launchGallery()
            }
        }

        @JavascriptInterface
        fun getPhoto(id: String): String = Photos.dataUri(this@MainActivity, id)
    }

    companion object {
        private const val REQ_NOTIF = 1
        private const val REQ_LOCATION = 2
        private const val REQ_VOICE = 3
        private const val REQ_RINGTONE = 4
        private const val REQ_AUDIO = 5
        private const val REQ_CAMERA = 6
        private const val REQ_GALLERY = 7
        private const val REQ_FCAM = 8
        private const val REQ_FGAL = 9
    }
}
