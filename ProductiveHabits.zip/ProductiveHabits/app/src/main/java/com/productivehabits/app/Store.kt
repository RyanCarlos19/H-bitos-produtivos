package com.productivehabits.app

import android.content.Context
import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

data class Habit(
    val id: String,
    val name: String,
    val emoji: String,
    val color: Int,
    val time: String,
    val days: List<Int>,
    val doneToday: Boolean,
    val streak: Int,
    val created: String,
    val done: Set<String>,
    val alarm: Boolean = true
) {
    fun scheduledToday(): Boolean = days.contains(Store.todayDow())
}

data class Ev(val id: String, val title: String, val date: String, val time: String)

object Store {
    private const val PREFS = "productive_habits"
    private const val KEY = "state"

    fun get(ctx: Context): String? =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)

    fun put(ctx: Context, json: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, json).apply()
    }

    fun keyOf(c: Calendar): String =
        "%04d-%02d-%02d".format(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))

    fun dowOf(c: Calendar): Int = c.get(Calendar.DAY_OF_WEEK) - 1
    fun todayDow(): Int = dowOf(Calendar.getInstance())
    fun todayKey(): String = keyOf(Calendar.getInstance())

    /** Dias seguidos (nos dias previstos) em que o hábito foi cumprido. */
    fun streakOf(days: List<Int>, done: Set<String>): Int {
        if (days.isEmpty()) return 0
        val c = Calendar.getInstance()
        if (days.contains(dowOf(c)) && !done.contains(keyOf(c))) c.add(Calendar.DAY_OF_YEAR, -1)
        var n = 0
        var guard = 0
        while (guard++ < 400) {
            if (!days.contains(dowOf(c))) { c.add(Calendar.DAY_OF_YEAR, -1); continue }
            if (done.contains(keyOf(c))) { n++; c.add(Calendar.DAY_OF_YEAR, -1) } else break
        }
        return n
    }

    fun habits(ctx: Context): List<Habit> {
        val raw = get(ctx) ?: return emptyList()
        return try {
            val arr = JSONObject(raw).optJSONArray("habits") ?: return emptyList()
            val today = todayKey()
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val daysArr = o.optJSONArray("days") ?: JSONArray()
                val days = (0 until daysArr.length()).map { daysArr.getInt(it) }
                val done = HashSet<String>()
                o.optJSONObject("done")?.let { d ->
                    val it = d.keys()
                    while (it.hasNext()) done.add(it.next())
                }
                Habit(
                    id = o.getString("id"),
                    name = o.optString("name"),
                    emoji = o.optString("emoji"),
                    color = try { Color.parseColor(o.optString("color", "#3B4BDB")) } catch (e: Exception) { Color.BLUE },
                    time = o.optString("time", "09:00"),
                    days = days,
                    doneToday = done.contains(today),
                    streak = streakOf(days, done),
                    created = o.optString("created", ""),
                    done = done,
                    alarm = o.optBoolean("alarm", true)
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun today(ctx: Context): List<Habit> = habits(ctx).filter { it.scheduledToday() }

    /** Dias seguidos em que TODOS os hábitos previstos foram concluídos. */
    fun perfectStreak(ctx: Context): Int {
        val hs = habits(ctx)
        if (hs.isEmpty()) return 0
        fun stats(c: Calendar): Pair<Int, Int> {
            val k = keyOf(c)
            val d = dowOf(c)
            var tot = 0
            var dn = 0
            for (h in hs) {
                if (h.created > k || !h.days.contains(d)) continue
                tot++
                if (h.done.contains(k)) dn++
            }
            return Pair(tot, dn)
        }
        val c = Calendar.getInstance()
        val t = stats(c)
        if (t.first > 0 && t.second < t.first) c.add(Calendar.DAY_OF_YEAR, -1)
        var n = 0
        var guard = 0
        while (guard++ < 400) {
            val s = stats(c)
            if (s.first == 0) { c.add(Calendar.DAY_OF_YEAR, -1); continue }
            if (s.second == s.first) { n++; c.add(Calendar.DAY_OF_YEAR, -1) } else break
        }
        return n
    }

    fun events(ctx: Context): List<Ev> {
        val raw = get(ctx) ?: return emptyList()
        return try {
            val arr = JSONObject(raw).optJSONArray("events") ?: return emptyList()
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Ev(o.getString("id"), o.optString("title"), o.optString("date"), o.optString("time", "09:00"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun quoteEnabled(ctx: Context): Boolean {
        val raw = get(ctx) ?: return true
        return try {
            JSONObject(raw).optJSONObject("settings")?.optBoolean("quote", true) ?: true
        } catch (e: Exception) {
            true
        }
    }

    private fun mutate(ctx: Context, id: String, onlyIfNotDone: Boolean) {
        val raw = get(ctx) ?: return
        try {
            val state = JSONObject(raw)
            val arr = state.optJSONArray("habits") ?: return
            val key = todayKey()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.optString("id") != id) continue
                val done = o.optJSONObject("done") ?: JSONObject().also { o.put("done", it) }
                if (done.has(key)) {
                    if (!onlyIfNotDone) done.remove(key)
                } else {
                    done.put(key, true)
                }
            }
            put(ctx, state.toString())
        } catch (e: Exception) {
        }
    }

    fun toggle(ctx: Context, id: String) = mutate(ctx, id, false)
    fun markDone(ctx: Context, id: String) = mutate(ctx, id, true)
}
