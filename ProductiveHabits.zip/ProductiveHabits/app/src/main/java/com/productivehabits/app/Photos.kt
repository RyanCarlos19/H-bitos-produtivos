package com.productivehabits.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.util.Base64
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream

object Photos {
    private fun dir(ctx: Context) = File(ctx.filesDir, "photos").apply { mkdirs() }
    fun file(ctx: Context, id: String) = File(dir(ctx), "$id.jpg")

    fun setPending(ctx: Context, id: String) {
        ctx.getSharedPreferences("ph_photo", Context.MODE_PRIVATE).edit().putString("pending", id).apply()
    }

    fun pending(ctx: Context): String? =
        ctx.getSharedPreferences("ph_photo", Context.MODE_PRIVATE).getString("pending", null)

    fun saveFromUri(ctx: Context, id: String, uri: Uri): Boolean {
        val bytes = try {
            ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
        } catch (e: Exception) { null } ?: return false
        return saveBytes(ctx, id, bytes)
    }

    fun saveFromFile(ctx: Context, id: String, f: File): Boolean {
        val bytes = try { f.readBytes() } catch (e: Exception) { return false }
        return saveBytes(ctx, id, bytes)
    }

    private fun saveBytes(ctx: Context, id: String, bytes: ByteArray): Boolean {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (bounds.outWidth / sample > 2200 || bounds.outHeight / sample > 2200) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return false

            val orientation = try {
                ExifInterface(ByteArrayInputStream(bytes))
                    .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } catch (e: Exception) { ExifInterface.ORIENTATION_NORMAL }
            val rot = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            val scale = Math.min(1f, 1280f / Math.max(bmp.width, bmp.height))
            if (rot != 0f || scale < 1f) {
                val m = Matrix()
                m.postRotate(rot)
                m.postScale(scale, scale)
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            FileOutputStream(file(ctx, id)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 82, it) }
            Tracker.setPhoto(ctx, id, true)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun dataUri(ctx: Context, id: String): String {
        val f = file(ctx, id)
        if (!f.exists()) return ""
        return try {
            "data:image/jpeg;base64," + Base64.encodeToString(f.readBytes(), Base64.NO_WRAP)
        } catch (e: Exception) { "" }
    }

    fun delete(ctx: Context, id: String) {
        try { file(ctx, id).delete() } catch (e: Exception) {}
    }
}
