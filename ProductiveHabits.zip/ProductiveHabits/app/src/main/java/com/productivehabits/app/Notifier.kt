package com.productivehabits.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon

object Notifier {
    private const val CHANNEL = "habits"

    fun show(ctx: Context, h: Habit) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Lembretes de hábitos", NotificationManager.IMPORTANCE_HIGH)
        )
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), flags)
        val doneIntent = Intent(ctx, ActionReceiver::class.java)
            .setAction(ActionReceiver.ACTION_DONE)
            .putExtra("id", h.id)
        val done = PendingIntent.getBroadcast(ctx, h.id.hashCode(), doneIntent, flags)
        val action = Notification.Action.Builder(
            Icon.createWithResource(ctx, R.drawable.ic_stat), "Feito", done
        ).build()

        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("${h.emoji} ${h.name}")
            .setContentText("Hora de cumprir seu hábito")
            .setContentIntent(open)
            .setAutoCancel(true)
            .addAction(action)
            .build()
        nm.notify(h.id.hashCode(), n)
    }

    fun cancel(ctx: Context, id: String) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(id.hashCode())
    }
}
