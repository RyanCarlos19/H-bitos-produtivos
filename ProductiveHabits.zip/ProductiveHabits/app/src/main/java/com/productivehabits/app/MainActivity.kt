package com.productivehabits.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import org.json.JSONObject
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var pendingType: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")

        askNotificationPermission()
        Scheduler.scheduleAll(this)
    }

    override fun onResume() {
        super.onResume()
        reloadState()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_LOCATION) {
            val type = pendingType
            pendingType = null
            if (hasFineLocation() && type != null) {
                launchTracking(type)
            } else if (!hasFineLocation()) {
                web.evaluateJavascript("window.__locDenied && window.__locDenied()", null)
            }
        }
        reloadState()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VOICE && resultCode == RESULT_OK) {
            val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (text != null) {
                web.evaluateJavascript("window.__voiceResult && window.__voiceResult(" + JSONObject.quote(text) + ")", null)
            }
        }
    }

    private fun startVoice() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Diga seu compromisso")
        try {
            startActivityForResult(i, REQ_VOICE)
        } catch (e: Exception) {
            web.evaluateJavascript("window.__voiceFail && window.__voiceFail()", null)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    private fun reloadState() {
        if (::web.isInitialized) {
            web.evaluateJavascript("window.__reload && window.__reload()", null)
        }
    }

    private fun hasNotifPermission(): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun hasFineLocation(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun askNotificationPermission() {
        if (!hasNotifPermission()) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
        }
    }

    private fun launchTracking(type: String) {
        if (Tracker.active) return
        val i = Intent(this, TrackingService::class.java)
            .setAction(TrackingService.ACTION_START)
            .putExtra("type", type)
        startForegroundService(i)
    }

    inner class Bridge {
        @JavascriptInterface
        fun getState(): String? = Store.get(this@MainActivity)

        @JavascriptInterface
        fun saveState(json: String) {
            Store.put(this@MainActivity, json)
            Scheduler.scheduleAll(this@MainActivity)
            HabitWidget.updateAll(this@MainActivity)
        }

        @JavascriptInterface
        fun notifGranted(): Boolean = hasNotifPermission()

        @JavascriptInterface
        fun requestNotifications() {
            runOnUiThread { askNotificationPermission() }
        }

        @JavascriptInterface
        fun testNotification(id: String) {
            Store.habits(this@MainActivity).find { it.id == id }?.let {
                Notifier.show(this@MainActivity, it)
            }
        }

        // ---- Voz, frase do dia ----
        @JavascriptInterface
        fun startVoice() {
            runOnUiThread { this@MainActivity.startVoice() }
        }

        @JavascriptInterface
        fun getQuote(): String = Quotes.forToday(this@MainActivity).toJson()

        @JavascriptInterface
        fun testQuote() {
            QuoteNotifier.show(this@MainActivity, Quotes.forToday(this@MainActivity))
        }

        // ---- Atividades físicas ----
        @JavascriptInterface
        fun getTracking(): String = Tracker.snapshot(this@MainActivity)

        @JavascriptInterface
        fun getSessions(): String = Tracker.sessionsJson(this@MainActivity)

        @JavascriptInterface
        fun hasLocation(): Boolean = hasFineLocation()

        @JavascriptInterface
        fun startTracking(type: String) {
            runOnUiThread {
                if (!hasFineLocation()) {
                    pendingType = type
                    requestPermissions(
                        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                        REQ_LOCATION
                    )
                } else {
                    launchTracking(type)
                }
            }
        }

        @JavascriptInterface
        fun togglePause() {
            startService(Intent(this@MainActivity, TrackingService::class.java).setAction(TrackingService.ACTION_TOGGLE))
        }

        @JavascriptInterface
        fun stopTracking() {
            startService(Intent(this@MainActivity, TrackingService::class.java).setAction(TrackingService.ACTION_STOP))
        }
    }

    companion object {
        private const val REQ_NOTIF = 1
        private const val REQ_LOCATION = 2
        private const val REQ_VOICE = 3
    }
}
