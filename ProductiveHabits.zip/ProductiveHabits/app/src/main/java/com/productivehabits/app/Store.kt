package com.productivehabits.app

import android.content.Context
import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

data class Habit(
    val id: String,
    val name: String,
    val emoji: String,
    val color: Int,
    val time: String,
    val days: List<Int>,
    val doneToday: Boolean
) {
    fun scheduledToday(): Boolean = days.contains(Store.todayDow())
}

object Store {
    private const val PREFS = "productive_habits"
    private const val KEY = "state"

    fun get(ctx: Context): String? =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)

    fun put(ctx: Context, json: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, json).apply()
    }

    fun todayDow(): Int = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1

    fun todayKey(): String {
        val c = Calendar.getInstance()
        return "%04d-%02d-%02d".format(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }

    fun habits(ctx: Context): List<Habit> {
        val raw = get(ctx) ?: return emptyList()
        return try {
            val arr = JSONObject(raw).optJSONArray("habits") ?: return emptyList()
            val key = todayKey()
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val daysArr = o.optJSONArray("days") ?: JSONArray()
                Habit(
                    id = o.getString("id"),
                    name = o.optString("name"),
                    emoji = o.optString("emoji"),
                    color = try { Color.parseColor(o.optString("color", "#3B4BDB")) } catch (e: Exception) { Color.BLUE },
                    time = o.optString("time", "09:00"),
                    days = (0 until daysArr.length()).map { daysArr.getInt(it) },
                    doneToday = o.optJSONObject("done")?.has(key) == true
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun today(ctx: Context): List<Habit> = habits(ctx).filter { it.scheduledToday() }

    private fun mutate(ctx: Context, id: String, onlyIfNotDone: Boolean) {
        val raw = get(ctx) ?: return
        try {
            val state = JSONObject(raw)
            val arr = state.optJSONArray("habits") ?: return
            val key = todayKey()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.optString("id") != id) continue
                val done = o.optJSONObject("done") ?: JSONObject().also { o.put("done", it) }
                if (done.has(key)) {
                    if (!onlyIfNotDone) done.remove(key)
                } else {
                    done.put(key, true)
                }
            }
            put(ctx, state.toString())
        } catch (e: Exception) {
        }
    }

    fun toggle(ctx: Context, id: String) = mutate(ctx, id, false)
    fun markDone(ctx: Context, id: String) = mutate(ctx, id, true)
}
