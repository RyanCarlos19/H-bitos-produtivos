package com.productivehabits.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.view.View
import android.widget.RemoteViews

class HabitWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { mgr.updateAppWidget(it, build(ctx, it)) }
        mgr.notifyAppWidgetViewDataChanged(ids, R.id.w_list)
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        if (intent.action == ACTION_TOGGLE) {
            val id = intent.getStringExtra("id")
            if (id != null) {
                val h = Store.habits(ctx).find { it.id == id }
                if (h != null && h.scheduledToday()) Store.toggle(ctx, id)
            }
            updateAll(ctx)
        }
    }

    companion object {
        const val ACTION_TOGGLE = "com.productivehabits.app.TOGGLE"

        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, HabitWidget::class.java))
            if (ids.isEmpty()) return
            ids.forEach { mgr.updateAppWidget(it, build(ctx, it)) }
            mgr.notifyAppWidgetViewDataChanged(ids, R.id.w_list)
        }

        private fun build(ctx: Context, widgetId: Int): RemoteViews {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_habits)

            // Lista com TODOS os hábitos (rolável)
            val svc = Intent(ctx, HabitWidgetService::class.java)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
            svc.data = Uri.parse(svc.toUri(Intent.URI_INTENT_SCHEME))
            rv.setRemoteAdapter(R.id.w_list, svc)
            rv.setEmptyView(R.id.w_list, R.id.w_empty)

            val today = Store.today(ctx)
            val done = today.count { it.doneToday }
            rv.setTextViewText(R.id.w_progress, "$done/${today.size}")
            rv.setProgressBar(R.id.w_bar, 100, if (today.isEmpty()) 0 else done * 100 / today.size, false)

            val perfect = Store.perfectStreak(ctx)
            rv.setTextViewText(
                R.id.w_streak,
                if (perfect > 0) "🔥 $perfect ${if (perfect == 1) "dia seguido" else "dias seguidos"} com 100%"
                else "Conclua todos os hábitos de hoje para iniciar sua sequência"
            )

            val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), flags)
            rv.setOnClickPendingIntent(R.id.w_header, open)
            rv.setOnClickPendingIntent(R.id.w_empty, open)

            // Modelo de clique das linhas (cada linha preenche o id do hábito)
            val template = Intent(ctx, HabitWidget::class.java).setAction(ACTION_TOGGLE)
            val mutable = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(ctx, 0, template, PendingIntent.FLAG_UPDATE_CURRENT or mutable)
            rv.setPendingIntentTemplate(R.id.w_list, pi)

            rv.setViewVisibility(R.id.w_streak, View.VISIBLE)
            return rv
        }
    }
}
