package com.productivehabits.app

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getStringExtra("id") ?: return
        val habit = Store.habits(ctx).find { it.id == id } ?: return
        if (!habit.doneToday) Notifier.show(ctx, habit)
        Scheduler.scheduleNext(ctx, habit)
    }
}

class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        when (intent.action) {
            ACTION_DONE -> {
                val id = intent.getStringExtra("id") ?: return
                Store.markDone(ctx, id)
                Notifier.cancel(ctx, id)
                HabitWidget.updateAll(ctx)
            }
            ACTION_DISMISS -> {
                val nid = intent.getIntExtra("nid", 0)
                val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.cancel(nid)
            }
        }
    }

    companion object {
        const val ACTION_DONE = "com.productivehabits.app.DONE"
        const val ACTION_DISMISS = "com.productivehabits.app.DISMISS"
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            Tracker.ensureLoaded(ctx)
            Tracker.finish(ctx)
        }
        Scheduler.scheduleAll(ctx)
        HabitWidget.updateAll(ctx)
    }
}
