package com.productivehabits.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import java.util.Calendar

object EventScheduler {
    private const val PREFS = "ph_ev_alarms"

    fun triggerAt(e: Ev): Long? {
        return try {
            val d = e.date.split("-").map { it.toInt() }
            val t = e.time.split(":").map { it.toInt() }
            Calendar.getInstance().apply {
                set(d[0], d[1] - 1, d[2], t[0], t[1], 0)
                set(Calendar.MILLISECOND, 0)
            }.timeInMillis
        } catch (ex: Exception) {
            null
        }
    }

    fun scheduleAll(ctx: Context) {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.getStringSet("ids", emptySet())?.forEach { cancel(ctx, it) }
        val now = System.currentTimeMillis()
        val ids = HashSet<String>()
        for (e in Store.events(ctx)) {
            val at = triggerAt(e) ?: continue
            if (at <= now) continue
            schedule(ctx, e, at)
            ids.add(e.id)
        }
        prefs.edit().putStringSet("ids", ids).apply()
    }

    private fun schedule(ctx: Context, e: Ev, at: Long) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val show = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pending(ctx, e.id))
    }

    private fun cancel(ctx: Context, id: String) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(ctx, id))
    }

    private fun pending(ctx: Context, id: String): PendingIntent {
        val intent = Intent(ctx, EventReceiver::class.java)
            .setAction("com.productivehabits.app.EVENT.$id")
            .putExtra("id", id)
        return PendingIntent.getBroadcast(
            ctx, ("ev$id").hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}

class EventReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getStringExtra("id") ?: return
        val ev = Store.events(ctx).find { it.id == id } ?: return
        EventNotifier.show(ctx, ev)
    }
}

object EventNotifier {
    fun show(ctx: Context, e: Ev) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = AlarmSound.channelId(ctx)

        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val nid = ("ev" + e.id).hashCode()
        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), flags)
        val dismissIntent = Intent(ctx, ActionReceiver::class.java)
            .setAction(ActionReceiver.ACTION_DISMISS)
            .putExtra("nid", nid)
        val dismiss = PendingIntent.getBroadcast(ctx, nid, dismissIntent, flags)
        val action = Notification.Action.Builder(
            Icon.createWithResource(ctx, R.drawable.ic_stat), "Dispensar", dismiss
        ).build()

        val n = Notification.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("⏰ ${e.title}")
            .setContentText("Compromisso agora • ${e.time}")
            .setCategory(Notification.CATEGORY_ALARM)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setContentIntent(open)
            .setAutoCancel(true)
            .setTimeoutAfter(180_000L)
            .addAction(action)
            .build()
        n.flags = n.flags or Notification.FLAG_INSISTENT
        nm.notify(nid, n)
    }
}
