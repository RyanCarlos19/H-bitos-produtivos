package com.productivehabits.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONObject
import java.util.Calendar
import java.util.Random

data class Quote(val cat: String, val text: String, val author: String?) {
    fun toJson(): String = JSONObject()
        .put("cat", cat)
        .put("text", text)
        .put("author", author ?: JSONObject.NULL)
        .toString()
}

object Quotes {
    private const val PREFS = "ph_quotes"

    // Ideias de negócio (texto original)
    private val BIZ = listOf(
        "Assinatura de marmitas saudáveis para escritórios do seu bairro. Comece com 10 clientes e um cardápio de 5 pratos antes de investir em estrutura.",
        "Organização de armários e cozinhas cobrada por hora. Baixo investimento, ticket alto e indicação boca a boca. Mostre o antes e depois nas redes.",
        "Lavagem de carros a seco em estacionamentos de condomínios e empresas. Cobre mensalidade e atenda vários carros no mesmo lugar.",
        "Fotos de produtos para pequenos lojistas. Um celular bom, fundo branco e boa luz já permitem vender pacotes de 10 fotos.",
        "Gestão de Instagram para negócios locais: perfil, 12 posts por mês e respostas rápidas. Cobre uma mensalidade fixa.",
        "Aulas de reforço ou idiomas online em pequenos grupos. Três alunos por turma rendem mais que aulas individuais e dão menos trabalho.",
        "Comida caseira congelada por encomenda: lasanhas, caldos e molhos. Venda para quem não tem tempo de cozinhar durante a semana.",
        "Limpeza de piscinas por assinatura mensal. Receita recorrente e, em muitos bairros, pouca concorrência organizada.",
        "Compra e revenda de móveis usados restaurados. Aprenda a lixar, pintar e trocar ferragens: o lucro vem da transformação.",
        "Planilhas e painéis prontos para pequenos negócios (fluxo de caixa, estoque, metas). Crie uma vez e venda muitas vezes.",
        "Passeio de cães e pet sitter em condomínios. Comece pelos vizinhos, peça avaliações e cresça por indicação.",
        "Marmitaria fitness com planos semanais. Foque em um nicho (emagrecimento, ganho de massa) e feche parceria com academias.",
        "Kits de presentes personalizados para empresas: fim de ano, aniversário de clientes e boas-vindas a novos funcionários.",
        "Conserto de celulares e notebooks a domicílio. O diferencial é a conveniência e uma garantia clara.",
        "Atendimento e agenda por WhatsApp para consultórios e salões. Muitos profissionais perdem clientes pela demora nas respostas.",
        "Mini cursos práticos sobre algo que você domina. Teste a ideia com uma aula ao vivo paga antes de gravar tudo.",
        "Aluguel de equipamentos pouco usados: barracas, ferramentas, caixas de som. Compre usado e deixe rendendo.",
        "Montagem de móveis. Parece simples, mas a demanda é constante e as pessoas pagam para não perder o fim de semana.",
        "Hortas e jardins verticais para apartamentos e restaurantes. Venda a instalação e a manutenção mensal.",
        "Vídeos curtos para empresas locais em pacote mensal: gravação, edição e legendas.",
        "Bolos e doces em porções individuais para entrega. Embalagem bonita e boas fotos permitem cobrar mais pelo mesmo produto.",
        "Contabilidade simplificada para MEIs, com lembretes de impostos e emissão de notas. Cobre uma mensalidade acessível.",
        "Aulas de informática para idosos. Há muita procura e pouca oferta paciente e bem explicada.",
        "Produto de nicho com estoque mínimo: escolha um público específico, resolva um problema dele e comece com poucas unidades.",
        "Tradução e legendagem para criadores de conteúdo e pequenas empresas. Um portfólio de 3 trabalhos já abre portas.",
        "Brechó online com curadoria. Escolha um estilo, fotografe bem e conte a história de cada peça."
    )

    // Mensagens motivacionais (texto original)
    private val MOT = listOf(
        "Você não precisa fazer tudo hoje. Precisa fazer bem o próximo passo. Comece por ele.",
        "Constância vence intensidade. Um pouco todos os dias supera muito de vez em quando.",
        "O desconforto de agora é o investimento no seu eu de daqui a um ano.",
        "Não espere se sentir motivado. Comece, e a motivação costuma aparecer no caminho.",
        "Compare-se apenas com quem você foi ontem. Isso já é progresso suficiente para celebrar.",
        "Todo especialista já foi iniciante. A diferença é que ele não desistiu nos primeiros meses.",
        "Seus hábitos de hoje escrevem a sua história de amanhã. Capriche no capítulo de hoje.",
        "Um dia ruim não apaga uma semana boa. Respire, ajuste e volte ao plano.",
        "Pequenas vitórias diárias constroem grandes conquistas. Marque o primeiro hábito do dia logo cedo.",
        "Disciplina é escolher o que você mais quer em vez do que você quer agora.",
        "Errar faz parte. Parar é que é opcional.",
        "Seu futuro agradece cada vez que você faz o que prometeu a si mesmo.",
        "Foque no processo: se você cuidar dos hábitos, os resultados aparecem.",
        "Comece antes de estar pronto. A preparação perfeita não existe; a prática ajusta o resto.",
        "Cuidar de si não é luxo: é o que sustenta tudo o que você quer construir.",
        "Ajude alguém hoje. Uma palavra gentil pode mudar o dia de uma pessoa, e o seu também.",
        "Seja paciente com o processo e exigente com a sua constância.",
        "Sua melhor ideia só vira realidade quando sai da cabeça. Anote, planeje e dê o primeiro passo hoje.",
        "Cada 'não' que você ouve te aproxima de um 'sim'. Continue tentando com inteligência.",
        "Energia vem de sono, movimento e propósito. Cuide dos três e o resto flui.",
        "O que você fizer nos próximos 30 minutos já define o tom do seu dia. Escolha bem.",
        "Resultados extraordinários vêm de rotinas simples repetidas por tempo suficiente.",
        "Quem ensina aprende duas vezes. Compartilhe hoje algo que você sabe.",
        "Hoje é um bom dia para ser 1% melhor do que ontem."
    )

    // Filósofos e livros (autor indicado; "adaptado" = tradução livre)
    private val WIS = listOf(
        Pair("Enquanto adiamos, a vida passa.", "Sêneca, Cartas a Lucílio"),
        Pair("Não é que tenhamos pouco tempo; é que perdemos muito dele.", "Sêneca, Sobre a Brevidade da Vida (adaptado)"),
        Pair("A alma se tinge da cor dos seus pensamentos.", "Marco Aurélio, Meditações (adaptado)"),
        Pair("O que está no caminho torna-se o caminho.", "Marco Aurélio, Meditações (adaptado)"),
        Pair("Uma vida sem reflexão não vale a pena ser vivida.", "Sócrates, segundo Platão"),
        Pair("Não são os fatos que perturbam as pessoas, mas o julgamento que fazem deles.", "Epicteto (adaptado)"),
        Pair("Uma jornada de mil milhas começa com um único passo.", "Lao Tsé, Tao Te Ching"),
        Pair("Quem tem um porquê para viver suporta quase qualquer como.", "Friedrich Nietzsche"),
        Pair("Aquilo que precisamos aprender a fazer, aprendemos fazendo.", "Aristóteles (adaptado)"),
        Pair("Somos o que repetidamente fazemos. A excelência, então, não é um ato, mas um hábito.", "Will Durant, sobre Aristóteles"),
        Pair("Quando não podemos mudar uma situação, somos desafiados a mudar a nós mesmos.", "Viktor Frankl, Em Busca de Sentido (adaptado)"),
        Pair("Você não sobe ao nível das suas metas; você cai ao nível dos seus sistemas.", "James Clear, Hábitos Atômicos (adaptado)"),
        Pair("Cada ação que você toma é um voto no tipo de pessoa que deseja se tornar.", "James Clear, Hábitos Atômicos (adaptado)"),
        Pair("Preço é o que você paga; valor é o que você leva.", "Warren Buffett"),
        Pair("Tudo vale a pena se a alma não é pequena.", "Fernando Pessoa, Mensagem"),
        Pair("A primeira e melhor vitória é conquistar a si mesmo.", "Platão, As Leis (adaptado)"),
        Pair("Tudo o que a mente humana pode conceber e acreditar, ela pode conquistar.", "Napoleon Hill, Pense e Enriqueça (adaptado)")
    )

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun forToday(ctx: Context): Quote {
        val p = prefs(ctx)
        val today = Store.todayKey()
        if (p.getString("date", "") == today) {
            val text = p.getString("text", null)
            if (text != null) {
                return Quote(p.getString("cat", "mot") ?: "mot", text, p.getString("author", null))
            }
        }
        val rnd = Random()
        val r = rnd.nextDouble()
        // Mais peso para ideias de negócio e motivação
        val cat = if (r < 0.40) "biz" else if (r < 0.75) "mot" else "wis"
        val size = when (cat) { "biz" -> BIZ.size; "mot" -> MOT.size; else -> WIS.size }
        val recent = (p.getString("recent", "") ?: "").split(",").filter { it.isNotEmpty() }.toMutableList()
        var idx: Int
        var tries = 0
        do {
            idx = rnd.nextInt(size)
            tries++
        } while (recent.contains("$cat:$idx") && tries < 30)
        recent.add("$cat:$idx")
        while (recent.size > 30) recent.removeAt(0)

        val q = when (cat) {
            "biz" -> Quote(cat, BIZ[idx], null)
            "mot" -> Quote(cat, MOT[idx], null)
            else -> Quote(cat, WIS[idx].first, WIS[idx].second)
        }
        p.edit()
            .putString("date", today)
            .putString("cat", q.cat)
            .putString("text", q.text)
            .putString("author", q.author)
            .putString("recent", recent.joinToString(","))
            .apply()
        return q
    }
}

object QuoteNotifier {
    private const val CHANNEL = "daily_quote"

    fun show(ctx: Context, q: Quote) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Frase do dia", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val title = when (q.cat) {
            "biz" -> "💡 Ideia de negócio do dia"
            "mot" -> "🚀 Para começar o dia"
            else -> "📚 Para refletir hoje"
        }
        val body = if (q.author != null) "“${q.text}”\n— ${q.author}" else q.text
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(q.text)
            .setStyle(Notification.BigTextStyle().bigText(body))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(7001, n)
    }
}

object QuoteScheduler {
    fun scheduleNext(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(ctx)
        if (!Store.quoteEnabled(ctx)) {
            am.cancel(pi)
            return
        }
        val c = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 8)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (c.timeInMillis <= System.currentTimeMillis() + 1000) c.add(Calendar.DAY_OF_YEAR, 1)
        try {
            val canExact = android.os.Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
            if (canExact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.timeInMillis, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.timeInMillis, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.timeInMillis, pi)
        }
    }

    private fun pending(ctx: Context): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, 7001, Intent(ctx, QuoteReceiver::class.java).setAction("com.productivehabits.app.QUOTE"),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
}

class QuoteReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (Store.quoteEnabled(ctx)) QuoteNotifier.show(ctx, Quotes.forToday(ctx))
        QuoteScheduler.scheduleNext(ctx)
    }
}
