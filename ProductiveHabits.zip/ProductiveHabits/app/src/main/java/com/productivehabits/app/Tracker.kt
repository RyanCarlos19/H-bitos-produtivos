package com.productivehabits.app

import android.content.Context
import android.location.Location
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

object Fmt {
    val PT: Locale = Locale("pt", "BR")

    /** Abaixo de 1 km mostra metros ("350 m"); a partir de 1 km mostra "1,10 km". */
    fun distance(m: Double): String =
        if (m < 1000.0) "${m.toInt()} m" else String.format(PT, "%.2f km", m / 1000.0)

    fun mmss(totalSec: Double): String {
        var m = (totalSec / 60).toInt()
        var s = Math.round(totalSec % 60).toInt()
        if (s == 60) { m += 1; s = 0 }
        return String.format(Locale.US, "%d:%02d", m, s)
    }
}

object Tracker {
    private const val PREFS = "ph_tracker"

    var active = false
        private set
    var paused = false
        private set
    var type = "run"
        private set
    var distance = 0.0
        private set

    private var elapsedBefore = 0L
    private var segmentStart = 0L
    private var last: Location? = null
    private var loaded = false

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun ensureLoaded(ctx: Context) {
        if (loaded) return
        loaded = true
        val p = prefs(ctx)
        active = p.getBoolean("active", false)
        paused = p.getBoolean("paused", false)
        type = p.getString("type", "run") ?: "run"
        distance = if (p.contains("distanceD")) java.lang.Double.longBitsToDouble(p.getLong("distanceD", 0L)) else 0.0
        elapsedBefore = p.getLong("elapsedBefore", 0L)
        segmentStart = p.getLong("segmentStart", 0L)
    }

    private fun persist(ctx: Context) {
        prefs(ctx).edit()
            .putBoolean("active", active)
            .putBoolean("paused", paused)
            .putString("type", type)
            .putLong("distanceD", java.lang.Double.doubleToRawLongBits(distance))
            .putLong("elapsedBefore", elapsedBefore)
            .putLong("segmentStart", segmentStart)
            .apply()
    }

    @Synchronized
    fun elapsed(): Long =
        elapsedBefore + if (active && !paused) System.currentTimeMillis() - segmentStart else 0L

    @Synchronized
    fun start(ctx: Context, t: String) {
        ensureLoaded(ctx)
        if (active) return
        type = t
        active = true
        paused = false
        distance = 0.0
        elapsedBefore = 0L
        segmentStart = System.currentTimeMillis()
        last = null
        persist(ctx)
    }

    @Synchronized
    fun pause(ctx: Context) {
        ensureLoaded(ctx)
        if (!active || paused) return
        elapsedBefore = elapsed()
        paused = true
        last = null
        persist(ctx)
    }

    @Synchronized
    fun resume(ctx: Context) {
        ensureLoaded(ctx)
        if (!active || !paused) return
        paused = false
        segmentStart = System.currentTimeMillis()
        last = null
        persist(ctx)
    }

    @Synchronized
    fun finish(ctx: Context) {
        ensureLoaded(ctx)
        if (!active) return
        val el = elapsed()
        if (distance >= 1.0 || el > 10_000L) saveSession(ctx, el)
        active = false
        paused = false
        last = null
        persist(ctx)
    }

    private fun saveSession(ctx: Context, el: Long) {
        val p = prefs(ctx)
        val old = try { JSONArray(p.getString("sessions", "[]")) } catch (e: Exception) { JSONArray() }
        val out = JSONArray()
        out.put(
            JSONObject()
                .put("type", type)
                .put("distance", distance)
                .put("duration", el)
                .put("endedAt", System.currentTimeMillis())
        )
        for (i in 0 until minOf(old.length(), 49)) out.put(old.get(i))
        p.edit().putString("sessions", out.toString()).apply()
    }

    @Synchronized
    fun sessionsJson(ctx: Context): String = prefs(ctx).getString("sessions", "[]") ?: "[]"

    @Synchronized
    fun snapshot(ctx: Context): String {
        ensureLoaded(ctx)
        return JSONObject()
            .put("active", active)
            .put("paused", paused)
            .put("type", type)
            .put("distance", distance)
            .put("elapsed", elapsed())
            .toString()
    }

    private fun minStep() = when (type) { "walk" -> 3.0; "run" -> 4.0; "swim" -> 5.0; else -> 6.0 }
    private fun maxSpeed() = when (type) { "walk" -> 5.0; "run" -> 10.0; "swim" -> 3.0; else -> 20.0 }

    /** Soma a distância de uma nova leitura de GPS, filtrando ruído e saltos impossíveis. */
    @Synchronized
    fun onLocation(ctx: Context, loc: Location): Boolean {
        ensureLoaded(ctx)
        if (!active || paused) return false
        val maxAcc = if (type == "swim") 40f else 30f
        if (loc.hasAccuracy() && loc.accuracy > maxAcc) return false

        val prev = last
        if (prev == null) { last = loc; return true }

        val dt = (loc.elapsedRealtimeNanos - prev.elapsedRealtimeNanos) / 1e9
        if (dt <= 0.0) return false
        val d = prev.distanceTo(loc).toDouble()
        val acc = if (loc.hasAccuracy()) loc.accuracy.toDouble() else 10.0
        val noise = maxOf(minStep(), minOf(acc, 15.0) * 0.5)
        if (d < noise) return false
        if (loc.hasSpeed() && loc.speed < 0.4f && d < 15.0) return false
        if (d / dt > maxSpeed()) return false

        distance += d
        last = loc
        persist(ctx)
        return true
    }

    fun emoji(t: String = type) = when (t) { "walk" -> "🚶"; "swim" -> "🏊"; "bike" -> "🚴"; else -> "🏃" }
    fun verb(t: String = type) = when (t) { "walk" -> "Caminhando"; "swim" -> "Nadando"; "bike" -> "Pedalando"; else -> "Correndo" }

    @Synchronized
    fun paceText(): String {
        val d = distance
        val el = elapsed()
        if (d < 50.0 || el <= 0L) return "Ritmo —"
        return when (type) {
            "bike" -> String.format(Fmt.PT, "%.1f km/h", d / 1000.0 / (el / 3_600_000.0))
            "swim" -> "Ritmo ${Fmt.mmss(el / 1000.0 / (d / 100.0))} /100 m"
            else -> "Ritmo ${Fmt.mmss(el / 1000.0 / (d / 1000.0))} /km"
        }
    }
}
