package com.productivehabits.app

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.widget.RemoteViews
import android.widget.RemoteViewsService

class HabitWidgetService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory = Factory(applicationContext)

    private class Factory(private val ctx: Context) : RemoteViewsFactory {
        private var items: List<Habit> = emptyList()

        override fun onCreate() {}

        override fun onDataSetChanged() {
            items = Store.habits(ctx)
                .sortedWith(compareByDescending<Habit> { it.scheduledToday() }.thenBy { it.time })
        }

        override fun onDestroy() {}

        override fun getCount(): Int = items.size

        override fun getViewAt(position: Int): RemoteViews {
            val h = items[position]
            val rv = RemoteViews(ctx.packageName, R.layout.widget_item)
            val active = h.scheduledToday()
            val dim = Color.parseColor("#9A9FC4")
            rv.setTextViewText(R.id.i_mark, if (!active) "–" else if (h.doneToday) "✔" else "○")
            rv.setTextColor(R.id.i_mark, if (active) h.color else dim)
            rv.setTextViewText(R.id.i_name, "${h.emoji} ${h.name}")
            rv.setTextColor(R.id.i_name, if (!active || h.doneToday) dim else Color.parseColor("#1B1F3B"))
            rv.setTextViewText(R.id.i_streak, if (h.streak > 0) "🔥${h.streak}" else "")
            rv.setTextViewText(R.id.i_time, h.time)
            rv.setOnClickFillInIntent(R.id.i_root, Intent().putExtra("id", h.id))
            return rv
        }

        override fun getLoadingView(): RemoteViews? = null
        override fun getViewTypeCount(): Int = 1
        override fun getItemId(position: Int): Long = items[position].id.hashCode().toLong()
        override fun hasStableIds(): Boolean = true
    }
}
