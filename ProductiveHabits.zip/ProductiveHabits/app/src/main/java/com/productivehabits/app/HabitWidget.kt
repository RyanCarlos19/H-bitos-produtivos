package com.productivehabits.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.View
import android.widget.RemoteViews

class HabitWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val views = build(ctx)
        ids.forEach { mgr.updateAppWidget(it, views) }
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        if (intent.action == ACTION_TOGGLE) {
            intent.getStringExtra("id")?.let { Store.toggle(ctx, it) }
            updateAll(ctx)
        }
    }

    companion object {
        const val ACTION_TOGGLE = "com.productivehabits.app.TOGGLE"
        private const val MAX_ROWS = 4

        private val rows = intArrayOf(R.id.row0, R.id.row1, R.id.row2, R.id.row3)
        private val marks = intArrayOf(R.id.m0, R.id.m1, R.id.m2, R.id.m3)
        private val names = intArrayOf(R.id.n0, R.id.n1, R.id.n2, R.id.n3)
        private val times = intArrayOf(R.id.t0, R.id.t1, R.id.t2, R.id.t3)

        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, HabitWidget::class.java))
            if (ids.isNotEmpty()) {
                val views = build(ctx)
                ids.forEach { mgr.updateAppWidget(it, views) }
            }
        }

        private fun build(ctx: Context): RemoteViews {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_habits)
            val today = Store.today(ctx)
            val done = today.count { it.doneToday }
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

            rv.setTextViewText(R.id.w_progress, "$done/${today.size}")
            rv.setProgressBar(R.id.w_bar, 100, if (today.isEmpty()) 0 else done * 100 / today.size, false)
            rv.setViewVisibility(R.id.w_empty, if (today.isEmpty()) View.VISIBLE else View.GONE)

            val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), flags)
            rv.setOnClickPendingIntent(R.id.w_header, open)
            rv.setOnClickPendingIntent(R.id.w_empty, open)

            for (i in 0 until MAX_ROWS) {
                if (i < today.size) {
                    val h = today[i]
                    rv.setViewVisibility(rows[i], View.VISIBLE)
                    rv.setTextViewText(marks[i], if (h.doneToday) "✔" else "○")
                    rv.setTextColor(marks[i], h.color)
                    rv.setTextViewText(names[i], "${h.emoji} ${h.name}")
                    rv.setTextColor(names[i], if (h.doneToday) Color.parseColor("#9A9FC4") else Color.parseColor("#1B1F3B"))
                    rv.setTextViewText(times[i], h.time)
                    val intent = Intent(ctx, HabitWidget::class.java)
                        .setAction(ACTION_TOGGLE)
                        .putExtra("id", h.id)
                    val pi = PendingIntent.getBroadcast(ctx, h.id.hashCode() + 7, intent, flags)
                    rv.setOnClickPendingIntent(rows[i], pi)
                } else {
                    rv.setViewVisibility(rows[i], View.GONE)
                }
            }

            if (today.size > MAX_ROWS) {
                rv.setViewVisibility(R.id.w_more, View.VISIBLE)
                rv.setTextViewText(R.id.w_more, "+${today.size - MAX_ROWS} no app")
            } else {
                rv.setViewVisibility(R.id.w_more, View.GONE)
            }
            return rv
        }
    }
}
