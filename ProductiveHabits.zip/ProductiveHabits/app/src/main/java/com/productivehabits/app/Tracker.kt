package com.productivehabits.app

import android.content.Context
import android.location.Location
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale

object Fmt {
    val PT: Locale = Locale("pt", "BR")

    /** Abaixo de 1 km mostra metros ("350 m"); a partir de 1 km mostra "1,10 km". */
    fun distance(m: Double): String =
        if (m < 1000.0) "${m.toInt()} m" else String.format(PT, "%.2f km", m / 1000.0)

    fun mmss(totalSec: Double): String {
        var m = (totalSec / 60).toInt()
        var s = Math.round(totalSec % 60).toInt()
        if (s == 60) { m += 1; s = 0 }
        return String.format(Locale.US, "%d:%02d", m, s)
    }
}

/** Filtro de Kalman simples para suavizar o ruído das coordenadas do GPS. */
class GpsKalman(private val qMetersPerSec: Double) {
    private var ts = 0L
    private var variance = -1.0
    var lat = 0.0
        private set
    var lng = 0.0
        private set

    fun process(la: Double, lo: Double, accuracy: Float, tsMs: Long) {
        val a = maxOf(accuracy, 1f).toDouble()
        if (variance < 0) {
            ts = tsMs; lat = la; lng = lo; variance = a * a
            return
        }
        val dt = tsMs - ts
        if (dt > 0) {
            variance += dt * qMetersPerSec * qMetersPerSec / 1000.0
            ts = tsMs
        }
        val k = variance / (variance + a * a)
        lat += k * (la - lat)
        lng += k * (lo - lng)
        variance = (1 - k) * variance
    }
}

object Tracker {
    private const val PREFS = "ph_tracker"

    var active = false
        private set
    var paused = false
        private set
    var type = "run"
        private set
    var distance = 0.0
        private set
    var startedAt = 0L
        private set

    @Volatile var lastLat = Double.NaN
    @Volatile var lastLon = Double.NaN

    private var elapsedBefore = 0L
    private var segmentStart = 0L
    private var loaded = false

    private val route = ArrayList<DoubleArray>()
    private var filter: GpsKalman? = null
    private var havePrev = false
    private var prevLat = 0.0
    private var prevLon = 0.0
    private var prevT = 0L
    private var prevSpeed = -1.0

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun ensureLoaded(ctx: Context) {
        if (loaded) return
        loaded = true
        val p = prefs(ctx)
        active = p.getBoolean("active", false)
        paused = p.getBoolean("paused", false)
        type = p.getString("type", "run") ?: "run"
        distance = if (p.contains("distanceD")) java.lang.Double.longBitsToDouble(p.getLong("distanceD", 0L)) else 0.0
        elapsedBefore = p.getLong("elapsedBefore", 0L)
        segmentStart = p.getLong("segmentStart", 0L)
        startedAt = p.getLong("startedAt", 0L)
        route.clear()
        val raw = p.getString("route", "") ?: ""
        if (raw.isNotEmpty()) {
            for (pt in raw.split(";")) {
                val c = pt.split(",")
                if (c.size == 2) {
                    val la = c[0].toDoubleOrNull()
                    val lo = c[1].toDoubleOrNull()
                    if (la != null && lo != null) route.add(doubleArrayOf(la, lo))
                }
            }
        }
    }

    private fun persist(ctx: Context) {
        prefs(ctx).edit()
            .putBoolean("active", active)
            .putBoolean("paused", paused)
            .putString("type", type)
            .putLong("distanceD", java.lang.Double.doubleToRawLongBits(distance))
            .putLong("elapsedBefore", elapsedBefore)
            .putLong("segmentStart", segmentStart)
            .putLong("startedAt", startedAt)
            .apply()
    }

    private fun persistRoute(ctx: Context) {
        val sb = StringBuilder()
        for ((i, pt) in route.withIndex()) {
            if (i > 0) sb.append(';')
            sb.append(String.format(Locale.US, "%.6f,%.6f", pt[0], pt[1]))
        }
        prefs(ctx).edit().putString("route", sb.toString()).apply()
    }

    @Synchronized
    fun elapsed(): Long =
        elapsedBefore + if (active && !paused) System.currentTimeMillis() - segmentStart else 0L

    private fun resetFilter() {
        filter = null
        havePrev = false
        prevSpeed = -1.0
    }

    @Synchronized
    fun start(ctx: Context, t: String) {
        ensureLoaded(ctx)
        if (active) return
        type = t
        active = true
        paused = false
        distance = 0.0
        elapsedBefore = 0L
        segmentStart = System.currentTimeMillis()
        startedAt = segmentStart
        route.clear()
        resetFilter()
        persist(ctx)
        persistRoute(ctx)
    }

    @Synchronized
    fun pause(ctx: Context) {
        ensureLoaded(ctx)
        if (!active || paused) return
        elapsedBefore = elapsed()
        paused = true
        resetFilter()
        persist(ctx)
        persistRoute(ctx)
    }

    @Synchronized
    fun resume(ctx: Context) {
        ensureLoaded(ctx)
        if (!active || !paused) return
        paused = false
        segmentStart = System.currentTimeMillis()
        resetFilter()
        persist(ctx)
    }

    @Synchronized
    fun finish(ctx: Context) {
        ensureLoaded(ctx)
        if (!active) return
        val el = elapsed()
        if (distance >= 1.0 || el > 10_000L) saveSession(ctx, el)
        active = false
        paused = false
        route.clear()
        resetFilter()
        persist(ctx)
        persistRoute(ctx)
    }

    private fun simplified(): JSONArray {
        val out = JSONArray()
        if (route.isEmpty()) return out
        val stride = Math.max(1, Math.ceil(route.size / 600.0).toInt())
        var i = 0
        while (i < route.size) {
            out.put(JSONArray().put(route[i][0]).put(route[i][1]))
            i += stride
        }
        val last = route[route.size - 1]
        if ((route.size - 1) % stride != 0) out.put(JSONArray().put(last[0]).put(last[1]))
        return out
    }

    private fun saveSession(ctx: Context, el: Long) {
        val id = java.lang.Long.toString(System.currentTimeMillis(), 36)
        try {
            val dir = File(ctx.filesDir, "routes").apply { mkdirs() }
            File(dir, "$id.json").writeText(simplified().toString())
        } catch (e: Exception) {
        }
        val p = prefs(ctx)
        val old = try { JSONArray(p.getString("sessions", "[]")) } catch (e: Exception) { JSONArray() }
        val out = JSONArray()
        out.put(
            JSONObject()
                .put("id", id)
                .put("type", type)
                .put("distance", distance)
                .put("duration", el)
                .put("endedAt", System.currentTimeMillis())
                .put("photo", false)
        )
        for (i in 0 until minOf(old.length(), 199)) out.put(old.get(i))
        p.edit().putString("sessions", out.toString()).apply()
    }

    @Synchronized
    fun sessionsJson(ctx: Context): String = prefs(ctx).getString("sessions", "[]") ?: "[]"

    @Synchronized
    fun setPhoto(ctx: Context, id: String, has: Boolean) {
        val p = prefs(ctx)
        val arr = try { JSONArray(p.getString("sessions", "[]")) } catch (e: Exception) { return }
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("id") == id) o.put("photo", has)
        }
        p.edit().putString("sessions", arr.toString()).apply()
    }

    @Synchronized
    fun deleteSession(ctx: Context, id: String) {
        val p = prefs(ctx)
        val arr = try { JSONArray(p.getString("sessions", "[]")) } catch (e: Exception) { return }
        val out = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("id") != id) out.put(o)
        }
        p.edit().putString("sessions", out.toString()).apply()
        try { File(File(ctx.filesDir, "routes"), "$id.json").delete() } catch (e: Exception) {}
        Photos.delete(ctx, id)
    }

    fun routeFor(ctx: Context, id: String): String {
        return try {
            val f = File(File(ctx.filesDir, "routes"), "$id.json")
            if (f.exists()) f.readText() else "[]"
        } catch (e: Exception) {
            "[]"
        }
    }

    @Synchronized
    fun liveRoute(from: Int): String {
        val out = JSONArray()
        var i = maxOf(0, from)
        while (i < route.size) {
            out.put(JSONArray().put(route[i][0]).put(route[i][1]))
            i++
        }
        return out.toString()
    }

    @Synchronized
    fun snapshot(ctx: Context): String {
        ensureLoaded(ctx)
        val o = JSONObject()
            .put("active", active)
            .put("paused", paused)
            .put("type", type)
            .put("distance", distance)
            .put("elapsed", elapsed())
            .put("startedAt", startedAt)
        if (!lastLat.isNaN() && !lastLon.isNaN()) {
            o.put("lat", lastLat)
            o.put("lon", lastLon)
        }
        return o.toString()
    }

    private fun qFor() = when (type) { "walk" -> 2.0; "run" -> 3.0; "swim" -> 1.5; else -> 8.0 }
    private fun maxAcc() = when (type) { "swim" -> 35f; "bike" -> 25f; else -> 20f }
    private fun maxSpeed() = when (type) { "walk" -> 5.0; "run" -> 11.0; "swim" -> 3.0; else -> 22.0 }
    private fun stillSpeed() = when (type) { "swim" -> 0.3; else -> 0.5 }

    private fun hav(la1: Double, lo1: Double, la2: Double, lo2: Double): Double {
        val r = 6371000.0
        val dLa = Math.toRadians(la2 - la1)
        val dLo = Math.toRadians(lo2 - lo1)
        val a = Math.sin(dLa / 2) * Math.sin(dLa / 2) +
            Math.cos(Math.toRadians(la1)) * Math.cos(Math.toRadians(la2)) * Math.sin(dLo / 2) * Math.sin(dLo / 2)
        return 2 * r * Math.asin(Math.min(1.0, Math.sqrt(a)))
    }

    /**
     * Soma a distância de uma leitura de GPS.
     * - descarta leituras imprecisas;
     * - suaviza as coordenadas (Kalman);
     * - usa a velocidade medida pelo efeito Doppler do GPS (muito mais precisa que a diferença
     *   entre posições) quando disponível;
     * - ignora o "tremor" do GPS quando a pessoa está parada.
     */
    @Synchronized
    fun onLocation(ctx: Context, loc: Location): Boolean {
        ensureLoaded(ctx)
        if (!active || paused) return false
        val acc = if (loc.hasAccuracy()) loc.accuracy else 50f
        if (acc > maxAcc()) return false

        val tNs = loc.elapsedRealtimeNanos
        val f = filter ?: GpsKalman(qFor()).also { filter = it }
        f.process(loc.latitude, loc.longitude, acc, tNs / 1_000_000L)
        val lat = f.lat
        val lon = f.lng
        lastLat = lat
        lastLon = lon

        if (!havePrev) {
            prevLat = lat; prevLon = lon; prevT = tNs; prevSpeed = -1.0
            havePrev = true
            route.add(doubleArrayOf(lat, lon))
            return true
        }

        val dt = (tNs - prevT) / 1e9
        if (dt < 0.3) return false

        val d = hav(prevLat, prevLon, lat, lon)
        val dopplerOk = loc.hasSpeed() &&
            (!loc.hasSpeedAccuracy() || loc.speedAccuracyMetersPerSecond <= 1.5f)
        val speed = if (dopplerOk) loc.speed.toDouble() else d / dt

        if (speed > maxSpeed()) return false

        if (speed < stillSpeed()) {
            // Parado: não soma distância (evita o "tremor" do GPS)
            prevLat = lat; prevLon = lon; prevT = tNs; prevSpeed = 0.0
            return true
        }

        val inc = if (dopplerOk && dt <= 5.0) {
            val v0 = if (prevSpeed >= 0) prevSpeed else speed
            (v0 + speed) / 2.0 * dt
        } else {
            d
        }

        distance += inc
        prevLat = lat; prevLon = lon; prevT = tNs; prevSpeed = speed

        val last = route[route.size - 1]
        if (hav(last[0], last[1], lat, lon) >= 4.0) {
            route.add(doubleArrayOf(lat, lon))
            if (route.size % 20 == 0) persistRoute(ctx)
        }
        persist(ctx)
        return true
    }

    fun emoji(t: String = type) = when (t) { "walk" -> "🚶"; "swim" -> "🏊"; "bike" -> "🚴"; else -> "🏃" }
    fun verb(t: String = type) = when (t) { "walk" -> "Caminhando"; "swim" -> "Nadando"; "bike" -> "Pedalando"; else -> "Correndo" }

    @Synchronized
    fun paceText(): String {
        val d = distance
        val el = elapsed()
        if (d < 50.0 || el <= 0L) return "Ritmo —"
        return when (type) {
            "bike" -> String.format(Fmt.PT, "%.1f km/h", d / 1000.0 / (el / 3_600_000.0))
            "swim" -> "Ritmo ${Fmt.mmss(el / 1000.0 / (d / 100.0))} /100 m"
            else -> "Ritmo ${Fmt.mmss(el / 1000.0 / (d / 1000.0))} /km"
        }
    }
}
