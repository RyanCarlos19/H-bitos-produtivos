package com.productivehabits.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getStringExtra("id") ?: return
        val habit = Store.habits(ctx).find { it.id == id } ?: return
        if (!habit.doneToday) Notifier.show(ctx, habit)
        Scheduler.scheduleNext(ctx, habit)
    }
}

class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != ACTION_DONE) return
        val id = intent.getStringExtra("id") ?: return
        Store.markDone(ctx, id)
        Notifier.cancel(ctx, id)
        HabitWidget.updateAll(ctx)
    }

    companion object {
        const val ACTION_DONE = "com.productivehabits.app.DONE"
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Scheduler.scheduleAll(ctx)
        HabitWidget.updateAll(ctx)
    }
}
