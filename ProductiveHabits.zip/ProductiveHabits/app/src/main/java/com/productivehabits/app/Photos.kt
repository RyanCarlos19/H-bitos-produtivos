package com.productivehabits.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.util.Base64
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

object Photos {
    private fun dir(ctx: Context) = File(ctx.filesDir, "photos").apply { mkdirs() }
    fun file(ctx: Context, id: String) = File(dir(ctx), "$id.jpg")

    fun setPending(ctx: Context, id: String) {
        ctx.getSharedPreferences("ph_photo", Context.MODE_PRIVATE).edit().putString("pending", id).apply()
    }

    fun pending(ctx: Context): String? =
        ctx.getSharedPreferences("ph_photo", Context.MODE_PRIVATE).getString("pending", null)

    private fun readUri(ctx: Context, uri: Uri): ByteArray? = try {
        ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
    } catch (e: Exception) { null }

    /** Reduz, corrige a rotação (EXIF) e comprime em JPEG. */
    private fun encode(bytes: ByteArray, maxDim: Int, quality: Int): ByteArray? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (bounds.outWidth / sample > maxDim * 2 || bounds.outHeight / sample > maxDim * 2) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return null

            val orientation = try {
                ExifInterface(ByteArrayInputStream(bytes))
                    .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } catch (e: Exception) { ExifInterface.ORIENTATION_NORMAL }
            val rot = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            val scale = Math.min(1f, maxDim.toFloat() / Math.max(bmp.width, bmp.height))
            if (rot != 0f || scale < 1f) {
                val m = Matrix()
                m.postRotate(rot)
                m.postScale(scale, scale)
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, quality, out)
            out.toByteArray()
        } catch (e: Exception) {
            null
        }
    }

    private fun dataUriOf(f: File): String {
        if (!f.exists()) return ""
        return try {
            "data:image/jpeg;base64," + Base64.encodeToString(f.readBytes(), Base64.NO_WRAP)
        } catch (e: Exception) { "" }
    }

    // ---------- fotos das atividades ----------
    fun saveFromUri(ctx: Context, id: String, uri: Uri): Boolean {
        val bytes = readUri(ctx, uri) ?: return false
        return saveBytes(ctx, id, bytes)
    }

    fun saveFromFile(ctx: Context, id: String, f: File): Boolean {
        val bytes = try { f.readBytes() } catch (e: Exception) { return false }
        return saveBytes(ctx, id, bytes)
    }

    private fun saveBytes(ctx: Context, id: String, bytes: ByteArray): Boolean {
        val jpg = encode(bytes, 1280, 82) ?: return false
        return try {
            FileOutputStream(file(ctx, id)).use { it.write(jpg) }
            Tracker.setPhoto(ctx, id, true)
            true
        } catch (e: Exception) { false }
    }

    fun dataUri(ctx: Context, id: String): String = dataUriOf(file(ctx, id))

    fun delete(ctx: Context, id: String) {
        try { file(ctx, id).delete() } catch (e: Exception) {}
    }

    // ---------- fotos das refeições ----------
    private fun mealsDir(ctx: Context) = File(ctx.filesDir, "meals").apply { mkdirs() }
    fun foodTmp(ctx: Context) = File(mealsDir(ctx), "tmp.jpg")
    fun mealFile(ctx: Context, id: String) = File(mealsDir(ctx), "$id.jpg")
    private fun mealThumb(ctx: Context, id: String) = File(mealsDir(ctx), "${id}_t.jpg")

    /** Salva a foto escolhida como temporária (já reduzida) e devolve em data URI. */
    fun saveFoodTmpFromUri(ctx: Context, uri: Uri): String {
        val bytes = readUri(ctx, uri) ?: return ""
        return saveFoodTmp(ctx, bytes)
    }

    fun saveFoodTmpFromFile(ctx: Context, f: File): String {
        val bytes = try { f.readBytes() } catch (e: Exception) { return "" }
        return saveFoodTmp(ctx, bytes)
    }

    private fun saveFoodTmp(ctx: Context, bytes: ByteArray): String {
        val jpg = encode(bytes, 1024, 80) ?: return ""
        return try {
            FileOutputStream(foodTmp(ctx)).use { it.write(jpg) }
            dataUriOf(foodTmp(ctx))
        } catch (e: Exception) { "" }
    }

    fun clearFoodTmp(ctx: Context) {
        try { foodTmp(ctx).delete() } catch (e: Exception) {}
    }

    /** Guarda a foto temporária como foto definitiva da refeição (e cria uma miniatura). */
    fun commitMeal(ctx: Context, id: String): Boolean {
        val tmp = foodTmp(ctx)
        if (!tmp.exists()) return false
        return try {
            val bytes = tmp.readBytes()
            FileOutputStream(mealFile(ctx, id)).use { it.write(bytes) }
            val thumb = encode(bytes, 240, 75)
            if (thumb != null) FileOutputStream(mealThumb(ctx, id)).use { it.write(thumb) }
            tmp.delete()
            true
        } catch (e: Exception) { false }
    }

    fun mealThumbUri(ctx: Context, id: String): String = dataUriOf(mealThumb(ctx, id))
    fun mealPhotoUri(ctx: Context, id: String): String = dataUriOf(mealFile(ctx, id))

    fun deleteMeal(ctx: Context, id: String) {
        try { mealFile(ctx, id).delete() } catch (e: Exception) {}
        try { mealThumb(ctx, id).delete() } catch (e: Exception) {}
    }
}
