package com.productivehabits.app

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Estima calorias e macronutrientes de uma refeição a partir de foto e/ou descrição,
 * usando a API da Anthropic (Claude) com a chave que o próprio usuário cadastra no app.
 */
object FoodAnalyzer {
    private const val MODEL = "claude-sonnet-5-5"
    private const val PREFS = "ph_ai"

    private const val SYSTEM = """Você é um nutricionista que estima valores nutricionais de refeições a partir de uma foto e/ou da descrição do usuário.
Responda APENAS com um objeto JSON válido (sem markdown, sem texto antes ou depois) neste formato:
{"name":"nome curto da refeição","items":[{"name":"alimento","qty":"quantidade estimada (ex.: 150 g, 1 unidade)","kcal":0,"protein":0,"carbs":0,"fat":0}],"total":{"kcal":0,"protein":0,"carbs":0,"fat":0,"fiber":0},"confidence":"alta|média|baixa","notes":"observações curtas em português"}
Regras: macronutrientes em gramas, kcal em número inteiro; estime as porções pelo tamanho visual e pelo que o usuário descreveu (se ele informar quantidades, priorize-as); considere óleo, molhos e acompanhamentos visíveis; a soma dos itens deve ser igual ao total; se a imagem não tiver comida, devolva totais zerados e explique em notes; escreva em português do Brasil."""

    fun hasKey(ctx: Context): Boolean = key(ctx).isNotEmpty()

    private fun key(ctx: Context): String =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("key", "") ?: ""

    fun setKey(ctx: Context, k: String) {
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("key", k.trim()).apply()
    }

    fun analyze(
        ctx: Context,
        description: String,
        image: File?,
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        val apiKey = key(ctx)
        if (apiKey.isEmpty()) { onError("Cadastre sua chave de API primeiro."); return }
        Thread {
            try {
                val content = JSONArray()
                if (image != null && image.exists()) {
                    content.put(
                        JSONObject()
                            .put("type", "image")
                            .put(
                                "source", JSONObject()
                                    .put("type", "base64")
                                    .put("media_type", "image/jpeg")
                                    .put("data", Base64.encodeToString(image.readBytes(), Base64.NO_WRAP))
                            )
                    )
                }
                val desc = description.trim()
                val prompt = if (desc.isNotEmpty())
                    "Descrição do usuário: $desc\n\nEstime os valores nutricionais desta refeição."
                else
                    "Sem descrição. Estime os valores nutricionais da refeição da foto."
                content.put(JSONObject().put("type", "text").put("text", prompt))

                val body = JSONObject()
                    .put("model", MODEL)
                    .put("max_tokens", 1500)
                    .put("system", SYSTEM)
                    .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))

                val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 20000
                conn.readTimeout = 90000
                conn.doOutput = true
                conn.setRequestProperty("content-type", "application/json")
                conn.setRequestProperty("x-api-key", apiKey)
                conn.setRequestProperty("anthropic-version", "2023-06-01")
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

                val code = conn.responseCode
                val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                if (code !in 200..299) {
                    val detail = try { JSONObject(text).getJSONObject("error").optString("message") } catch (e: Exception) { "" }
                    onError(
                        when (code) {
                            401 -> "Chave de API inválida. Confira a chave cadastrada."
                            403 -> "Sem permissão para usar esta chave."
                            404 -> "Modelo indisponível para esta chave."
                            429 -> "Muitas análises seguidas. Tente de novo em instantes."
                            529 -> "Serviço sobrecarregado. Tente de novo em instantes."
                            else -> "Erro $code ao analisar. $detail"
                        }
                    )
                    return@Thread
                }
                val root = JSONObject(text)
                val blocks = root.getJSONArray("content")
                val sb = StringBuilder()
                for (i in 0 until blocks.length()) {
                    val b = blocks.getJSONObject(i)
                    if (b.optString("type") == "text") sb.append(b.optString("text"))
                }
                val raw = sb.toString()
                val a = raw.indexOf('{')
                val z = raw.lastIndexOf('}')
                if (a < 0 || z <= a) { onError("Não consegui interpretar a resposta. Tente de novo."); return@Thread }
                val parsed = JSONObject(raw.substring(a, z + 1))
                onResult(parsed.toString())
            } catch (e: java.net.UnknownHostException) {
                onError("Sem internet. Conecte-se para analisar a refeição.")
            } catch (e: java.net.SocketTimeoutException) {
                onError("A análise demorou demais. Tente de novo.")
            } catch (e: Exception) {
                onError("Não foi possível analisar agora. Tente de novo.")
            }
        }.start()
    }
}
