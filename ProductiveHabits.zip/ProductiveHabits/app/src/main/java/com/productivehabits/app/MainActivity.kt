package com.productivehabits.app

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {

    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")

        askNotificationPermission()
        Scheduler.scheduleAll(this)
    }

    override fun onResume() {
        super.onResume()
        reloadState()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        reloadState()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    private fun reloadState() {
        if (::web.isInitialized) {
            web.evaluateJavascript("window.__reload && window.__reload()", null)
        }
    }

    private fun hasNotifPermission(): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun askNotificationPermission() {
        if (!hasNotifPermission()) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun getState(): String? = Store.get(this@MainActivity)

        @JavascriptInterface
        fun saveState(json: String) {
            Store.put(this@MainActivity, json)
            Scheduler.scheduleAll(this@MainActivity)
            HabitWidget.updateAll(this@MainActivity)
        }

        @JavascriptInterface
        fun notifGranted(): Boolean = hasNotifPermission()

        @JavascriptInterface
        fun requestNotifications() {
            runOnUiThread { askNotificationPermission() }
        }

        @JavascriptInterface
        fun testNotification(id: String) {
            Store.habits(this@MainActivity).find { it.id == id }?.let {
                Notifier.show(this@MainActivity, it)
            }
        }
    }
}
