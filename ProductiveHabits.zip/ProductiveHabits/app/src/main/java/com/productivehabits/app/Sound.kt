package com.productivehabits.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.core.content.FileProvider
import java.io.File

/** Som do alarme escolhido pelo usuário (padrão, sons do app, som do sistema ou música do celular). */
object AlarmSound {
    private const val PREFS = "ph_sound"
    private var player: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun kind(ctx: Context): String = prefs(ctx).getString("kind", "default") ?: "default"
    fun value(ctx: Context): String = prefs(ctx).getString("value", "") ?: ""
    fun label(ctx: Context): String = prefs(ctx).getString("label", "Padrão do celular") ?: "Padrão do celular"

    fun uriFor(ctx: Context, kind: String, value: String): Uri = when (kind) {
        "raw" -> Uri.parse("android.resource://${ctx.packageName}/raw/$value")
        "system" -> Uri.parse(value)
        "file" -> FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", File(File(ctx.filesDir, "sounds"), value))
        else -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
    }

    private fun currentUri(ctx: Context): Uri =
        try { uriFor(ctx, kind(ctx), value(ctx)) } catch (e: Exception) { uriFor(ctx, "default", "") }

    /** Canal de notificação com o som atual (o som de um canal não pode ser alterado depois de criado). */
    fun channelId(ctx: Context): String {
        val ver = prefs(ctx).getInt("ver", 1)
        val id = "alarm_v$ver"
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val uri = currentUri(ctx)
        if (kind(ctx) == "file") {
            try { ctx.grantUriPermission("com.android.systemui", uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) {}
        }
        if (nm.getNotificationChannel(id) == null) {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val ch = NotificationChannel(id, "Alarmes de hábitos e compromissos", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(uri, attrs)
            ch.enableVibration(true)
            ch.vibrationPattern = longArrayOf(0, 600, 300, 600, 300, 600)
            ch.lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            nm.createNotificationChannel(ch)
        }
        return id
    }

    fun set(ctx: Context, kind: String, value: String, label: String) {
        val p = prefs(ctx)
        val ver = p.getInt("ver", 1)
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        try { nm.deleteNotificationChannel("alarm_v$ver") } catch (e: Exception) {}
        p.edit()
            .putString("kind", kind)
            .putString("value", value)
            .putString("label", label)
            .putInt("ver", ver + 1)
            .apply()
    }

    fun json(ctx: Context): String = org.json.JSONObject()
        .put("kind", kind(ctx)).put("value", value(ctx)).put("label", label(ctx)).toString()

    fun preview(ctx: Context, kind: String, value: String) {
        stopPreview()
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            mp.setDataSource(ctx, uriFor(ctx, kind, value))
            mp.setOnCompletionListener { stopPreview() }
            mp.prepare()
            mp.start()
            player = mp
            handler.postDelayed({ stopPreview() }, 8000)
        } catch (e: Exception) {
            stopPreview()
        }
    }

    fun stopPreview() {
        handler.removeCallbacksAndMessages(null)
        try { player?.stop() } catch (e: Exception) {}
        try { player?.release() } catch (e: Exception) {}
        player = null
    }
}
