package com.productivehabits.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon

object Notifier {
    private const val QUIET = "habits"

    fun show(ctx: Context, h: Habit) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = if (h.alarm) {
            AlarmSound.channelId(ctx)
        } else {
            nm.createNotificationChannel(NotificationChannel(QUIET, "Lembretes de hábitos", NotificationManager.IMPORTANCE_HIGH))
            QUIET
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val nid = h.id.hashCode()
        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), flags)
        val doneIntent = Intent(ctx, ActionReceiver::class.java)
            .setAction(ActionReceiver.ACTION_DONE)
            .putExtra("id", h.id)
        val done = PendingIntent.getBroadcast(ctx, nid, doneIntent, flags)
        val dismissIntent = Intent(ctx, ActionReceiver::class.java)
            .setAction(ActionReceiver.ACTION_DISMISS)
            .putExtra("nid", nid)
        val dismiss = PendingIntent.getBroadcast(ctx, nid + 1, dismissIntent, flags)
        val icon = Icon.createWithResource(ctx, R.drawable.ic_stat)

        val b = Notification.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("${h.emoji} ${h.name}")
            .setContentText("Hora de cumprir seu hábito")
            .setContentIntent(open)
            .setAutoCancel(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(Notification.Action.Builder(icon, "Feito", done).build())

        if (h.alarm) {
            b.setCategory(Notification.CATEGORY_ALARM)
                .setTimeoutAfter(60_000L)
                .addAction(Notification.Action.Builder(icon, "Parar alarme", dismiss).build())
        }
        val n = b.build()
        if (h.alarm) n.flags = n.flags or Notification.FLAG_INSISTENT
        nm.notify(nid, n)
    }

    fun cancel(ctx: Context, id: String) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(id.hashCode())
    }
}
